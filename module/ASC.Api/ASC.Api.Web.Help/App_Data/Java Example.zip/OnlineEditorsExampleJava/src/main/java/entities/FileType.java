
package entities;

public enum FileType {
    Text,
    Spreadsheet,
    Presentation
}