﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("OnlineEditorsExampleMVC")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ascensio System SIA")]
[assembly: AssemblyProduct("OnlineEditorsExampleMVC")]
[assembly: AssemblyCopyright("Ascensio System SIA 2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("5b0423f6-859c-4514-a5c7-483e25f9bd31")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
