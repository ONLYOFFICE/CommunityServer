﻿using System.Web.Http;

namespace OnlineEditorsExampleMVC
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
        }
    }
}
